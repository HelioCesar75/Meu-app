import 'package:shared_preferences/shared_preferences.dart';

class AuthService {
  static const _user = "user";
  static const _pass = "pass";

  Future<bool> register(String u, String p) async {
    if(u.isEmpty || p.isEmpty) return false;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_user, u);
    await prefs.setString(_pass, p);
    return true;
  }

  Future<bool> login(String u, String p) async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_user)==u && prefs.getString(_pass)==p;
  }

  Future<bool> isLogged() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_user) != null;
  }
}
